'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  weightKg: number;
  activeMedications: string; // comma-separated
  conditionsAllergies: string; // comma-separated or text
}

interface ProfileContextType {
  profiles: UserProfile[];
  activeProfileId: string;
  profile: UserProfile;
  selectProfile: (id: string) => void;
  updateProfile: (newProfile: Partial<UserProfile>) => void;
  addNewProfile: (profile: UserProfile) => void;
  isProfileModalOpen: boolean;
  setProfileModalOpen: (isOpen: boolean) => void;
}

const DEFAULT_PROFILES: UserProfile[] = [
  {
    id: 'p1',
    name: 'Child (Leo)',
    age: 6,
    weightKg: 14.5,
    activeMedications: 'Childrens Tylenol, Amoxicillin',
    conditionsAllergies: 'Penicillin Allergy, Mild Asthma',
  },
  {
    id: 'p2',
    name: 'Self (Alex)',
    age: 34,
    weightKg: 72.0,
    activeMedications: 'Atorvastatin 20mg, Lisinopril 10mg',
    conditionsAllergies: 'Hypertension, Hyperlipidemia',
  },
  {
    id: 'p3',
    name: 'Senior Parent (Martha)',
    age: 68,
    weightKg: 62.5,
    activeMedications: 'Warfarin 5mg, Metformin 500mg',
    conditionsAllergies: 'Type 2 Diabetes, Atrial Fibrillation',
  },
];

const STORAGE_KEY = 'medguard_multi_profiles_v2';
const ACTIVE_ID_KEY = 'medguard_active_profile_id_v2';

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export function ProfileProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<UserProfile[]>(DEFAULT_PROFILES);
  const [activeProfileId, setActiveProfileId] = useState<string>('p1');
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);

  useEffect(() => {
    try {
      const savedProfiles = localStorage.getItem(STORAGE_KEY);
      const savedActiveId = localStorage.getItem(ACTIVE_ID_KEY);
      if (savedProfiles) {
        setProfiles(JSON.parse(savedProfiles));
      }
      if (savedActiveId) {
        setActiveProfileId(savedActiveId);
      }
    } catch (e) {
      console.warn('Failed to load multi-profiles from localStorage:', e);
    }
  }, []);

  const activeProfile = profiles.find((p) => p.id === activeProfileId) || profiles[0] || DEFAULT_PROFILES[0];

  const selectProfile = (id: string) => {
    setActiveProfileId(id);
    try {
      localStorage.setItem(ACTIVE_ID_KEY, id);
    } catch (e) {}
  };

  const updateProfile = (updatedFields: Partial<UserProfile>) => {
    setProfiles((prev) => {
      const updated = prev.map((p) => (p.id === activeProfile.id ? { ...p, ...updatedFields } : p));
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const addNewProfile = (newP: UserProfile) => {
    setProfiles((prev) => {
      const updated = [...prev, newP];
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    selectProfile(newP.id);
  };

  return (
    <ProfileContext.Provider
      value={{
        profiles,
        activeProfileId,
        profile: activeProfile,
        selectProfile,
        updateProfile,
        addNewProfile,
        isProfileModalOpen,
        setProfileModalOpen,
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
}

export function useUserProfile() {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useUserProfile must be used within a ProfileProvider');
  }
  return context;
}
