'use client';

import React from 'react';
import { AlertCircle } from 'lucide-react';

export function DisclaimerBanner() {
  return (
    <footer className="fixed bottom-0 left-0 right-0 z-50 border-t-2 border-amber-400 bg-amber-50/95 py-2.5 px-4 backdrop-blur-md shadow-md">
      <div className="mx-auto flex max-w-7xl items-center justify-center gap-2 text-center text-xs font-bold text-amber-900 sm:text-sm">
        <AlertCircle className="h-4 w-4 shrink-0 text-amber-600 animate-pulse" />
        <span>
          DISCLAIMER: This app is a university project and AI-generated educational tool, not a substitute for professional medical advice.
        </span>
      </div>
    </footer>
  );
}
