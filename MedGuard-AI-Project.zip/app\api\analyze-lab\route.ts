import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, userConditions } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY environment variable is not configured.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    const prompt = `You are an expert medical lab report scanner.
Analyze this lab report image carefully.
User's Pre-existing conditions and allergies: "${userConditions || 'None specified'}"

Extract all lab test biomarkers found in the image.
For each biomarker, determine:
- Biomarker name (e.g., LDL Cholesterol, Glucose, Hemoglobin)
- Extracted numeric value
- Unit of measurement
- Reference range shown on report
- Status: "high" | "low" | "normal" | "borderline"
- Plain English explanation of what this metric means.
- Relevance to user's pre-existing conditions.

Also provide:
- A 1-2 sentence overall summary of the lab document.
- Exactly 3 targeted questions the user should ask their doctor based on these findings.

Respond strictly in JSON format with this structure:
{
  "reportSummary": "...",
  "metrics": [
    {
      "biomarker": "...",
      "value": "...",
      "unit": "...",
      "referenceRange": "...",
      "status": "high|low|normal|borderline",
      "plainEnglishMeaning": "...",
      "relevanceToConditions": "..."
    }
  ],
  "questionsForDoctor": ["Q1", "Q2", "Q3"]
}`;

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64,
          },
        },
        { text: prompt },
      ],
    });

    const text = response.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json(parsed);
    }

    return NextResponse.json({ error: 'Failed to parse JSON response from AI model' }, { status: 500 });
  } catch (error: any) {
    console.error('Error in analyze-lab API:', error);
    return NextResponse.json({ error: error?.message || 'Server error' }, { status: 500 });
  }
}
