'use client';

import React, { useState } from 'react';
import {
  Utensils,
  Upload,
  Sparkles,
  ShieldCheck,
  AlertOctagon,
  RefreshCw,
  Pill,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { useUserProfile } from '@/lib/profile-context';
import { analyzeFoodImageClient, MedDietAnalysisResponse } from '@/lib/ai-service';

export function MedDiet() {
  const { profile } = useUserProfile();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MedDietAnalysisResponse | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const loadGrapefruitSample = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#fff7ed';
      ctx.fillRect(0, 0, 600, 400);

      ctx.beginPath();
      ctx.arc(300, 200, 110, 0, 2 * Math.PI);
      ctx.fillStyle = '#f43f5e';
      ctx.fill();
      ctx.lineWidth = 12;
      ctx.strokeStyle = '#fb923c';
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('FRESH GRAPEFRUIT JUICE', 300, 200);
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#fff';
      ctx.fillText('Active Food Scanner Demo Item', 300, 230);
    }
    const sampleUrl = canvas.toDataURL('image/jpeg');
    setImagePreview(sampleUrl);
    handleAnalyze(sampleUrl);
  };

  const loadSafeMealSample = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#ecfdf5';
      ctx.fillRect(0, 0, 600, 400);

      ctx.fillStyle = '#047857';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('GRILLED SALMON & QUINOA SALAD', 300, 190);
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#065f46';
      ctx.fillText('Healthy Heart & Lean Protein Bowl', 300, 220);
    }
    const sampleUrl = canvas.toDataURL('image/jpeg');
    setImagePreview(sampleUrl);
    handleAnalyze(sampleUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async (base64Data: string) => {
    setLoading(true);
    setResult(null);
    try {
      const res = await analyzeFoodImageClient(base64Data, profile.activeMedications);
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-600/20">
            <Utensils className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">MedDiet • Food & Medication Scanner</h2>
            <p className="text-xs text-slate-500">
              Scans food ingredients against active medications ({profile.activeMedications || 'None specified'})
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={loadGrapefruitSample}
            className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-600 hover:text-white transition-all"
          >
            <Sparkles className="h-3.5 w-3.5" /> Test Grapefruit (Statin Warning)
          </button>
          <button
            onClick={loadSafeMealSample}
            className="flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-600 hover:text-white transition-all"
          >
            <Sparkles className="h-3.5 w-3.5" /> Test Safe Salmon Meal
          </button>
        </div>
      </div>

      {/* Upload Zone */}
      {!imagePreview && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          className={`relative flex flex-col items-center justify-center rounded-3xl border-2 border-dashed p-10 text-center transition-all ${
            dragActive
              ? 'border-indigo-500 bg-indigo-50'
              : 'border-slate-300 bg-white hover:border-slate-400 shadow-sm'
          }`}
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="absolute inset-0 cursor-pointer opacity-0"
          />
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-100 shadow-xs">
            <Upload className="h-8 w-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            Upload or Drag Food Photo / Meal Image
          </h3>
          <p className="mt-1 text-xs text-slate-500">
            Scan juices, fresh produce, dairy, cheeses, supplements, or cooked dishes
          </p>
          <div className="mt-6 flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1 text-[11px] font-medium text-slate-600">
            <Pill className="h-3.5 w-3.5 text-indigo-600" /> Checks against active meds: {profile.activeMedications}
          </div>
        </div>
      )}

      {/* Main Analysis Layout */}
      {imagePreview && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-3">
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
              <img
                src={imagePreview}
                alt="Food scan"
                className="h-56 w-full object-cover rounded-xl border border-slate-200"
              />
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">Food Item Source</span>
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setResult(null);
                  }}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-900"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> New Scan
                </button>
              </div>
            </div>

            {loading && (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-indigo-200 bg-indigo-50 p-6 text-center">
                <RefreshCw className="h-8 w-8 animate-spin text-indigo-600" />
                <p className="mt-3 text-xs font-bold text-indigo-800">
                  Identifying Ingredients & Checking Drug Interaction Matrix...
                </p>
              </div>
            )}
          </div>

          <div className="md:col-span-2 space-y-5">
            {result && (
              <>
                {result.safetyStatus === 'WARNING' ? (
                  <div className="overflow-hidden rounded-3xl border-2 border-rose-500 bg-rose-50 p-6 shadow-xl animate-pulse-slow">
                    <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
                      <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-rose-600 text-white shadow-lg shadow-rose-600/30">
                        <AlertOctagon className="h-12 w-12" />
                      </div>
                      <div>
                        <span className="rounded-full bg-rose-200 px-3 py-1 text-xs font-black tracking-widest text-rose-900 border border-rose-300 uppercase">
                          INTERACTION WARNING
                        </span>
                        <h3 className="mt-1 text-2xl font-black tracking-tight text-slate-900">
                          {result.riskTitle}
                        </h3>
                        <p className="mt-1 text-xs text-slate-700 font-semibold">
                          Identified Ingredients: {result.identifiedIngredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="mt-5 rounded-2xl border border-rose-200 bg-white p-4 text-xs leading-relaxed text-slate-800 shadow-xs">
                      <h4 className="font-bold text-rose-700 mb-1 flex items-center gap-1.5">
                        <Info className="h-4 w-4" /> Medical Interaction Rationale:
                      </h4>
                      <p>{result.explanation}</p>
                    </div>

                    <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl bg-rose-100 p-3 text-xs border border-rose-200">
                      <div className="flex items-center gap-2 text-rose-900">
                        <Pill className="h-4 w-4 shrink-0 text-rose-700" />
                        <span>Affected Medication: <strong className="text-slate-900">{result.interactingMedications.join(', ')}</strong></span>
                      </div>
                      <span className="font-bold text-rose-800">{result.recommendation}</span>
                    </div>
                  </div>
                ) : (
                  <div className="overflow-hidden rounded-3xl border-2 border-emerald-500 bg-emerald-50 p-6 shadow-xl">
                    <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
                      <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/30">
                        <ShieldCheck className="h-12 w-12" />
                      </div>
                      <div>
                        <span className="rounded-full bg-emerald-200 px-3 py-1 text-xs font-black tracking-widest text-emerald-900 border border-emerald-300 uppercase">
                          SAFE TO EAT
                        </span>
                        <h3 className="mt-1 text-2xl font-black tracking-tight text-slate-900">
                          {result.riskTitle}
                        </h3>
                        <p className="mt-1 text-xs text-slate-700 font-semibold">
                          Identified Ingredients: {result.identifiedIngredients.join(', ')}
                        </p>
                      </div>
                    </div>

                    <div className="mt-5 rounded-2xl border border-emerald-200 bg-white p-4 text-xs leading-relaxed text-slate-800 shadow-xs">
                      <h4 className="font-bold text-emerald-700 mb-1 flex items-center gap-1.5">
                        <CheckCircle2 className="h-4 w-4" /> Safety Evaluation:
                      </h4>
                      <p>{result.explanation}</p>
                    </div>

                    <div className="mt-4 rounded-xl bg-emerald-100 p-3 text-xs text-emerald-900 border border-emerald-200">
                      <strong>Recommendation:</strong> {result.recommendation}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
