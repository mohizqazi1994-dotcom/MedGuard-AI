import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const { imageBase64 } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY environment variable is not configured.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    const prompt = `You are a medical OCR vision parser for pediatric liquid medication labels.
Read the label image carefully.

STRICT MANDATE:
Extract ONLY:
1. The active drug name (e.g. "Acetaminophen", "Ibuprofen", "Amoxicillin") and commercial product name if visible.
2. The exact concentration ratio string (e.g. "160mg/5mL", "100mg/5mL", "250mg/5mL", "125mg/5mL").

DO NOT attempt to calculate any final dose volume or dosage for a patient. ONLY extract the raw label concentration metrics.

Respond strictly in JSON format:
{
  "drugName": "...",
  "concentrationStr": "...",
  "confidenceScore": 95,
  "notes": "..."
}`;

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64,
          },
        },
        { text: prompt },
      ],
    });

    const text = response.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json(parsed);
    }

    return NextResponse.json({ error: 'Failed to parse JSON response from AI model' }, { status: 500 });
  } catch (error: any) {
    console.error('Error in extract-dose API:', error);
    return NextResponse.json({ error: error?.message || 'Server error' }, { status: 500 });
  }
}
