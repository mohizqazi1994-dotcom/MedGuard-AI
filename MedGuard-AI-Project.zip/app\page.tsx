'use client';

import React, { useState } from 'react';
import { FileText, Utensils, Calculator, ShieldCheck, UserCheck } from 'lucide-react';
import { LabClear } from '@/components/LabClear';
import { MedDiet } from '@/components/MedDiet';
import { DoseGuide } from '@/components/DoseGuide';
import { useUserProfile } from '@/lib/profile-context';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'lab' | 'food' | 'dose'>('lab');
  const { profile, setProfileModalOpen } = useUserProfile();

  return (
    <div className="space-y-8">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-r from-white via-cyan-50/40 to-slate-50 p-6 sm:p-8 shadow-md">
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-cyan-200/30 blur-3xl" />
        <div className="absolute -left-20 -bottom-20 h-64 w-64 rounded-full bg-indigo-200/30 blur-3xl" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-200 bg-cyan-100/70 px-3.5 py-1 text-xs font-bold text-cyan-800">
              <ShieldCheck className="h-4 w-4" /> AI Vision + Deterministic Safety Architecture
            </div>
            <h1 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
              MedGuard<span className="bg-gradient-to-r from-cyan-600 to-indigo-600 bg-clip-text text-transparent"> AI</span> Health Dashboard
            </h1>
            <p className="max-w-2xl text-xs sm:text-sm text-slate-600">
              Cross-referencing medical lab reports, food-drug interaction risks, and pediatric liquid dosage calculations against your active patient profile.
            </p>
          </div>

          {/* Quick Active Patient Profile Card */}
          <div className="flex shrink-0 items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="space-y-1 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <UserCheck className="h-4 w-4 text-cyan-600" /> Active Patient
              </div>
              <div className="text-slate-600">
                Age: <strong className="text-slate-900">{profile.age} yrs</strong> • Weight: <strong className="text-cyan-700">{profile.weightKg} kg</strong>
              </div>
              <div className="text-[11px] text-slate-500 max-w-[200px] truncate">
                Meds: <span className="text-indigo-700 font-semibold">{profile.activeMedications || 'None'}</span>
              </div>
            </div>
            <button
              onClick={() => setProfileModalOpen(true)}
              className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 hover:border-cyan-500 hover:text-cyan-700 transition-colors"
            >
              Edit
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm">
        {/* Tab 1: LabClear */}
        <button
          onClick={() => setActiveTab('lab')}
          className={`flex flex-1 items-center justify-center gap-2.5 rounded-xl px-4 py-3 text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'lab'
              ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/20'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <FileText className="h-4 w-4" />
          <span>Feature 1: LabClear</span>
        </button>

        {/* Tab 2: MedDiet */}
        <button
          onClick={() => setActiveTab('food')}
          className={`flex flex-1 items-center justify-center gap-2.5 rounded-xl px-4 py-3 text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'food'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Utensils className="h-4 w-4" />
          <span>Feature 2: MedDiet</span>
        </button>

        {/* Tab 3: DoseGuide */}
        <button
          onClick={() => setActiveTab('dose')}
          className={`flex flex-1 items-center justify-center gap-2.5 rounded-xl px-4 py-3 text-xs sm:text-sm font-bold transition-all ${
            activeTab === 'dose'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Calculator className="h-4 w-4" />
          <span>Feature 3: DoseGuide</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="transition-all duration-300">
        {activeTab === 'lab' && <LabClear />}
        {activeTab === 'food' && <MedDiet />}
        {activeTab === 'dose' && <DoseGuide />}
      </div>
    </div>
  );
}
