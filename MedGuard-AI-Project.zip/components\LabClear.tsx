'use client';

import React, { useState } from 'react';
import {
  FileText,
  Upload,
  Sparkles,
  HelpCircle,
  CheckCircle,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Info,
} from 'lucide-react';
import { useUserProfile } from '@/lib/profile-context';
import { analyzeLabReportClient, LabClearAnalysisResponse } from '@/lib/ai-service';

export function LabClear() {
  const { profile } = useUserProfile();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<LabClearAnalysisResponse | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const loadSampleReport = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 600, 400);
      ctx.fillStyle = '#0284c7';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText('CLINICAL METABOLIC & LIPID LABORATORY REPORT', 30, 40);
      ctx.fillStyle = '#64748b';
      ctx.font = '14px monospace';
      ctx.fillText('Patient ID: #MG-88921   Date: 2026-07-27', 30, 70);
      ctx.fillText('----------------------------------------------------', 30, 90);
      ctx.fillStyle = '#e11d48';
      ctx.fillText('TEST: LDL Cholesterol       RESULT: 165 mg/dL  [HIGH]', 30, 130);
      ctx.fillStyle = '#d97706';
      ctx.fillText('TEST: Fasting Glucose      RESULT: 112 mg/dL  [BORDERLINE]', 30, 170);
      ctx.fillStyle = '#059669';
      ctx.fillText('TEST: Serum Creatinine     RESULT: 0.95 mg/dL [NORMAL]', 30, 210);
      ctx.fillStyle = '#e11d48';
      ctx.fillText('TEST: hs-CRP Inflamm       RESULT: 3.4 mg/L   [HIGH]', 30, 250);
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('LabClear Vision AI Ready for Scan Parsing...', 30, 330);
    }
    const sampleUrl = canvas.toDataURL('image/jpeg');
    setImagePreview(sampleUrl);
    handleAnalyze(sampleUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async (base64Data: string) => {
    setLoading(true);
    setResult(null);
    try {
      const res = await analyzeLabReportClient(base64Data, profile.conditionsAllergies);
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Feature Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-md shadow-cyan-600/20">
            <FileText className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">LabClear • Lab Report Explainer</h2>
            <p className="text-xs text-slate-500">
              AI Vision cross-references biomarkers against your pre-existing conditions ({profile.conditionsAllergies || 'None'})
            </p>
          </div>
        </div>
        <button
          onClick={loadSampleReport}
          className="flex items-center gap-2 rounded-xl border border-cyan-200 bg-cyan-50 px-4 py-2 text-xs font-bold text-cyan-700 hover:bg-cyan-600 hover:text-white transition-all"
        >
          <Sparkles className="h-4 w-4" /> Load Sample Lab Report
        </button>
      </div>

      {/* Upload Zone */}
      {!imagePreview && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          className={`relative flex flex-col items-center justify-center rounded-3xl border-2 border-dashed p-10 text-center transition-all ${
            dragActive
              ? 'border-cyan-500 bg-cyan-50'
              : 'border-slate-300 bg-white hover:border-slate-400 shadow-sm'
          }`}
        >
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={handleFileChange}
            className="absolute inset-0 cursor-pointer opacity-0"
          />
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-50 text-cyan-700 border border-cyan-100 shadow-xs">
            <Upload className="h-8 w-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            Upload or Drag Lab Report Photo / PDF
          </h3>
          <p className="mt-1 text-xs text-slate-500">
            Supports Blood Panels, Lipid Reports, Metabolic Panels, & Urinalysis
          </p>
          <div className="mt-6 flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1 text-[11px] font-medium text-slate-600">
            <Info className="h-3.5 w-3.5 text-cyan-600" /> Auto-matches conditions from Patient Profile
          </div>
        </div>
      )}

      {/* Processing & Results */}
      {imagePreview && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-3">
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
              <img
                src={imagePreview}
                alt="Lab Report"
                className="h-56 w-full object-cover rounded-xl border border-slate-200"
              />
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">Lab Document Source</span>
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setResult(null);
                  }}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-900"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Replace Image
                </button>
              </div>
            </div>

            {loading && (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-cyan-200 bg-cyan-50 p-6 text-center">
                <RefreshCw className="h-8 w-8 animate-spin text-cyan-600" />
                <p className="mt-3 text-xs font-bold text-cyan-800">
                  Scanning Biomarkers & Cross-Referencing Conditions...
                </p>
              </div>
            )}
          </div>

          <div className="md:col-span-2 space-y-4">
            {result && (
              <>
                <div className="rounded-2xl border border-cyan-100 bg-cyan-50/70 p-4 shadow-sm">
                  <div className="flex items-center gap-2 font-bold text-cyan-800 text-sm">
                    <Sparkles className="h-4 w-4" /> Lab Analysis Summary
                  </div>
                  <p className="mt-1 text-xs text-slate-700">{result.reportSummary}</p>
                </div>

                <div className="space-y-3">
                  <h3 className="text-xs font-bold tracking-wider text-slate-500 uppercase">
                    Extracted Biomarkers ({result.metrics.length})
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {result.metrics.map((metric, i) => {
                      let badgeBg = 'bg-emerald-100 text-emerald-800 border-emerald-200';
                      let icon = <CheckCircle className="h-4 w-4 text-emerald-600" />;
                      let cardBorder = 'border-slate-200 bg-white shadow-xs';

                      if (metric.status === 'high' || metric.status === 'low') {
                        badgeBg = 'bg-rose-100 text-rose-800 border-rose-200';
                        icon =
                          metric.status === 'high' ? (
                            <ArrowUpRight className="h-4 w-4 text-rose-600" />
                          ) : (
                            <ArrowDownRight className="h-4 w-4 text-rose-600" />
                          );
                        cardBorder = 'border-rose-200 bg-white shadow-sm';
                      } else if (metric.status === 'borderline') {
                        badgeBg = 'bg-amber-100 text-amber-800 border-amber-200';
                        icon = <AlertTriangle className="h-4 w-4 text-amber-600" />;
                        cardBorder = 'border-amber-200 bg-white shadow-xs';
                      }

                      return (
                        <div
                          key={i}
                          className={`rounded-2xl border p-4 transition-all ${cardBorder}`}
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-bold text-slate-900 text-sm">{metric.biomarker}</h4>
                              <div className="mt-1 flex items-baseline gap-1.5">
                                <span className="text-xl font-black text-slate-900">
                                  {metric.value}
                                </span>
                                <span className="text-xs text-slate-500">{metric.unit}</span>
                              </div>
                            </div>
                            <span
                              className={`flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${badgeBg}`}
                            >
                              {icon} {metric.status}
                            </span>
                          </div>

                          <div className="mt-2.5 text-[11px] text-slate-500">
                            Ref Range: <span className="text-slate-800 font-medium">{metric.referenceRange}</span>
                          </div>

                          <p className="mt-2 text-xs leading-relaxed text-slate-700">
                            {metric.plainEnglishMeaning}
                          </p>

                          {metric.relevanceToConditions && (
                            <div className="mt-3 rounded-xl bg-slate-50 p-2.5 text-[11px] text-slate-700 border border-slate-200">
                              <span className="font-bold text-cyan-800">Profile Match: </span>
                              {metric.relevanceToConditions}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-2xl border border-indigo-100 bg-indigo-50/60 p-5 shadow-sm">
                  <div className="flex items-center gap-2 font-bold text-indigo-900 text-sm">
                    <HelpCircle className="h-4 w-4 text-indigo-600" /> 3 Questions to Ask Your Doctor
                  </div>
                  <ul className="mt-3 space-y-2.5">
                    {result.questionsForDoctor.map((q, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2.5 rounded-xl bg-white p-3 text-xs text-slate-800 border border-slate-200 shadow-xs"
                      >
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-[10px] font-bold text-indigo-700">
                          {idx + 1}
                        </span>
                        <span>{q}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
