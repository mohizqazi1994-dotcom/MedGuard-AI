export interface DosageResult {
  drugName: string;
  weightKg: number;
  concentrationRatioStr: string; // e.g. "160mg/5mL" or "100mg/5mL"
  mgPerMl: number;
  standardMgPerKgRate: number; // e.g. 12.5 mg/kg for Acetaminophen
  calculatedDoseMg: number;
  calculatedDoseMl: number;
  mathSteps: string[];
  safetyWarnings: string[];
  maxDailyDoses: number;
  intervalHours: number;
}

// Standard pediatric dosing guidelines (mg/kg per single dose)
const PEDIATRIC_DOSING_RULES: Record<string, { mgPerKg: number; maxDosesPerDay: number; intervalHours: number; notes: string }> = {
  acetaminophen: { mgPerKg: 12.5, maxDosesPerDay: 5, intervalHours: 4, notes: "Maximum 75 mg/kg/day or 4000 mg/day." },
  tylenol: { mgPerKg: 12.5, maxDosesPerDay: 5, intervalHours: 4, notes: "Maximum 75 mg/kg/day or 4000 mg/day." },
  paracetamol: { mgPerKg: 12.5, maxDosesPerDay: 5, intervalHours: 4, notes: "Maximum 75 mg/kg/day." },
  ibuprofen: { mgPerKg: 10.0, maxDosesPerDay: 4, intervalHours: 6, notes: "Do not exceed 40 mg/kg/day. Take with food." },
  motrin: { mgPerKg: 10.0, maxDosesPerDay: 4, intervalHours: 6, notes: "Do not exceed 40 mg/kg/day." },
  advil: { mgPerKg: 10.0, maxDosesPerDay: 4, intervalHours: 6, notes: "Do not exceed 40 mg/kg/day." },
  amoxicillin: { mgPerKg: 20.0, maxDosesPerDay: 3, intervalHours: 8, notes: "Finish entire course prescribed by physician." },
  diphenhydramine: { mgPerKg: 1.25, maxDosesPerDay: 4, intervalHours: 6, notes: "May cause drowsiness. Consult pediatrician for under 2 yrs." },
  benadryl: { mgPerKg: 1.25, maxDosesPerDay: 4, intervalHours: 6, notes: "May cause drowsiness." },
};

/**
 * Parses concentration strings such as "160mg/5mL", "100mg / 5 mL", "250mg/5ml", or "32mg/ml"
 */
export function parseConcentration(str: string): { mg: number; ml: number; mgPerMl: number } {
  const regex = /(\d+(?:\.\d+)?)\s*mg\s*\/\s*(\d+(?:\.\d+)?)?\s*m[lL]/i;
  const match = str.match(regex);

  if (match) {
    const mg = parseFloat(match[1]);
    const ml = match[2] ? parseFloat(match[2]) : 1;
    if (!isNaN(mg) && !isNaN(ml) && ml > 0) {
      return { mg, ml, mgPerMl: mg / ml };
    }
  }

  // Fallback pattern if only single mg/mL number
  const singleRegex = /(\d+(?:\.\d+)?)\s*mg\/m[lL]/i;
  const singleMatch = str.match(singleRegex);
  if (singleMatch) {
    const mgPerMl = parseFloat(singleMatch[1]);
    return { mg: mgPerMl, ml: 1, mgPerMl };
  }

  // Default fallback for 160mg/5mL (32 mg/mL) if unparseable
  return { mg: 160, ml: 5, mgPerMl: 32 };
}

/**
 * Strictly deterministic pediatric dose calculator function
 */
export function calculatePediatricDose(
  drugNameInput: string,
  concentrationStr: string,
  weightKg: number
): DosageResult {
  const cleanDrugName = drugNameInput.trim().toLowerCase();
  const parsedConc = parseConcentration(concentrationStr);
  const mgPerMl = parsedConc.mgPerMl;

  // Match drug key in database or default to standard 12.5 mg/kg
  let matchedRuleKey = Object.keys(PEDIATRIC_DOSING_RULES).find((key) => cleanDrugName.includes(key));
  const rule = matchedRuleKey ? PEDIATRIC_DOSING_RULES[matchedRuleKey] : { mgPerKg: 12.5, maxDosesPerDay: 4, intervalHours: 6, notes: "Standard pediatric dosing reference applied." };

  const standardMgPerKgRate = rule.mgPerKg;
  const targetDoseMg = weightKg * standardMgPerKgRate;
  const calculatedDoseMl = targetDoseMg / mgPerMl;

  const mathSteps = [
    `1. Patient Weight = ${weightKg.toFixed(1)} kg`,
    `2. Standard Dose Rate = ${standardMgPerKgRate} mg/kg per dose`,
    `3. Target Dose (mg) = ${weightKg.toFixed(1)} kg × ${standardMgPerKgRate} mg/kg = ${targetDoseMg.toFixed(1)} mg`,
    `4. Concentration = ${parsedConc.mg} mg per ${parsedConc.ml} mL (${mgPerMl.toFixed(1)} mg/mL)`,
    `5. Volume (mL) = ${targetDoseMg.toFixed(1)} mg ÷ ${mgPerMl.toFixed(1)} mg/mL = ${calculatedDoseMl.toFixed(2)} mL`,
  ];

  const safetyWarnings: string[] = [
    `Always use a calibrated oral syringe or dosing cup (never a standard household kitchen spoon).`,
    `Dosing interval: Wait at least ${rule.intervalHours} hours between doses.`,
    `Maximum daily frequency: Do not exceed ${rule.maxDosesPerDay} doses in 24 hours.`,
    rule.notes,
  ];

  if (weightKg < 3) {
    safetyWarnings.unshift("WARNING: Weight under 3 kg requires immediate direct clinical neonatology supervision.");
  } else if (weightKg > 50) {
    safetyWarnings.unshift("NOTE: For children >50 kg, dose must not exceed maximum adult single dose limits.");
  }

  return {
    drugName: drugNameInput || "Pediatric Liquid Medication",
    weightKg,
    concentrationRatioStr: `${parsedConc.mg}mg / ${parsedConc.ml}mL`,
    mgPerMl,
    standardMgPerKgRate,
    calculatedDoseMg: Math.round(targetDoseMg * 10) / 10,
    calculatedDoseMl: Math.round(calculatedDoseMl * 100) / 100,
    mathSteps,
    safetyWarnings,
    maxDailyDoses: rule.maxDosesPerDay,
    intervalHours: rule.intervalHours,
  };
}
