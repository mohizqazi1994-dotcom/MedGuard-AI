'use client';

import React, { useState, useEffect } from 'react';
import { X, User, Scale, Pill, AlertTriangle, Save, CheckCircle2, Plus, Users } from 'lucide-react';
import { useUserProfile } from '@/lib/profile-context';

export function UserProfileModal() {
  const {
    profiles,
    activeProfileId,
    profile,
    selectProfile,
    updateProfile,
    addNewProfile,
    isProfileModalOpen,
    setProfileModalOpen,
  } = useUserProfile();

  const [name, setName] = useState(profile.name);
  const [age, setAge] = useState(profile.age);
  const [weightKg, setWeightKg] = useState(profile.weightKg);
  const [activeMedications, setActiveMedications] = useState(profile.activeMedications);
  const [conditionsAllergies, setConditionsAllergies] = useState(profile.conditionsAllergies);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  useEffect(() => {
    setName(profile.name);
    setAge(profile.age);
    setWeightKg(profile.weightKg);
    setActiveMedications(profile.activeMedications);
    setConditionsAllergies(profile.conditionsAllergies);
    setIsCreatingNew(false);
  }, [profile, activeProfileId, isProfileModalOpen]);

  if (!isProfileModalOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreatingNew) {
      const newP = {
        id: `p_${Date.now()}`,
        name: name || 'Family Member',
        age: Number(age) || 0,
        weightKg: Number(weightKg) || 0,
        activeMedications,
        conditionsAllergies,
      };
      addNewProfile(newP);
    } else {
      updateProfile({
        name,
        age: Number(age) || 0,
        weightKg: Number(weightKg) || 0,
        activeMedications,
        conditionsAllergies,
      });
    }
    setSavedToast(true);
    setTimeout(() => {
      setSavedToast(false);
      setProfileModalOpen(false);
    }, 600);
  };

  const handleStartNew = () => {
    setIsCreatingNew(true);
    setName('');
    setAge(4);
    setWeightKg(12);
    setActiveMedications('');
    setConditionsAllergies('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 border border-cyan-200">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Family Patient Profiles</h2>
              <p className="text-xs text-slate-500">
                Switch profiles to cross-reference meds & calculate pediatric doses
              </p>
            </div>
          </div>
          <button
            onClick={() => setProfileModalOpen(false)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Profile Switcher Pills */}
        <div className="mt-4 flex flex-wrap items-center gap-2 border-b border-slate-100 pb-4">
          {profiles.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => selectProfile(p.id)}
              className={`flex items-center gap-2 rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                p.id === activeProfileId && !isCreatingNew
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <User className="h-3.5 w-3.5" />
              <span>{p.name}</span>
              <span className="opacity-80">({p.weightKg}kg)</span>
            </button>
          ))}
          <button
            type="button"
            onClick={handleStartNew}
            className="flex items-center gap-1 rounded-xl border border-dashed border-cyan-400 bg-cyan-50 px-3 py-1.5 text-xs font-bold text-cyan-700 hover:bg-cyan-100"
          >
            <Plus className="h-3.5 w-3.5" /> Add Family Member
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="mt-4 space-y-4">
          <div>
            <label className="mb-1 block text-xs font-semibold text-slate-700">Profile Name / Identifier</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Leo (Son), Sarah (Self), Grandma"
              className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder-slate-400 focus:bg-white focus:border-cyan-600 focus:outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 flex items-center gap-1 text-xs font-semibold text-slate-700">
                <User className="h-3.5 w-3.5 text-cyan-600" /> Patient Age (Years)
              </label>
              <input
                type="number"
                min="0"
                max="120"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-cyan-600 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="mb-1 flex items-center gap-1 text-xs font-semibold text-slate-700">
                <Scale className="h-3.5 w-3.5 text-indigo-600" /> Exact Weight (kg)
              </label>
              <input
                type="number"
                min="1"
                max="250"
                step="0.1"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm font-bold text-cyan-700 focus:bg-white focus:border-cyan-600 focus:outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="mb-1 flex items-center gap-1 text-xs font-semibold text-slate-700">
              <Pill className="h-3.5 w-3.5 text-indigo-600" /> Active Medications
            </label>
            <textarea
              rows={2}
              value={activeMedications}
              onChange={(e) => setActiveMedications(e.target.value)}
              placeholder="e.g., Children's Tylenol, Atorvastatin, Lisinopril"
              className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-cyan-600 focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 flex items-center gap-1 text-xs font-semibold text-slate-700">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" /> Pre-existing Conditions & Allergies
            </label>
            <textarea
              rows={2}
              value={conditionsAllergies}
              onChange={(e) => setConditionsAllergies(e.target.value)}
              placeholder="e.g., Penicillin Allergy, Hypertension, Asthma"
              className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-cyan-600 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 pt-4">
            <span className="text-xs text-slate-400">Persisted locally in browser storage</span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setProfileModalOpen(false)}
                className="rounded-xl px-4 py-2 text-xs font-medium text-slate-500 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 rounded-xl bg-cyan-600 px-5 py-2 text-xs font-bold text-white shadow-md hover:bg-cyan-700"
              >
                {savedToast ? (
                  <>
                    <CheckCircle2 className="h-4 w-4" /> Saved!
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" /> {isCreatingNew ? 'Create Member' : 'Save Profile'}
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
