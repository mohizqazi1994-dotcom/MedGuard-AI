import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export async function POST(req: NextRequest) {
  try {
    const { imageBase64, activeMeds } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY environment variable is not configured.' },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({ apiKey });

    const prompt = `You are a clinical pharmacology and food-drug interaction scanner.
Analyze this image of a food item or meal.
User's Active Medications list: "${activeMeds || 'None specified'}"

Tasks:
1. Identify all visible ingredients and food items in the image.
2. Cross-reference identified food ingredients against the user's active medications for clinically documented negative food-drug interactions.
3. Determine safety status: "SAFE" or "WARNING".
4. If warning: Provide a clear risk title, detailed medical mechanism explanation, list of interacting medications, and safe recommendation/alternative.

Respond strictly in JSON format:
{
  "identifiedIngredients": ["Ingredient 1", "Ingredient 2"],
  "safetyStatus": "SAFE|WARNING",
  "riskTitle": "...",
  "explanation": "...",
  "interactingMedications": ["Med 1"],
  "recommendation": "..."
}`;

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64,
          },
        },
        { text: prompt },
      ],
    });

    const text = response.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json(parsed);
    }

    return NextResponse.json({ error: 'Failed to parse JSON response from AI model' }, { status: 500 });
  } catch (error: any) {
    console.error('Error in analyze-food API:', error);
    return NextResponse.json({ error: error?.message || 'Server error' }, { status: 500 });
  }
}
