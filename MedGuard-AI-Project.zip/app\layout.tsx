import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { ProfileProvider } from '@/lib/profile-context';
import { Navbar } from '@/components/Navbar';
import { UserProfileModal } from '@/components/UserProfileModal';
import { DisclaimerBanner } from '@/components/DisclaimerBanner';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'MedGuard AI • Personal Health Dashboard & Clinical Safety Engine',
  description:
    'Multimodal vision AI & deterministic clinical logic dashboard featuring LabClear, MedDiet, and DoseGuide.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-slate-50 text-slate-900 min-h-screen relative`}>
        <ProfileProvider>
          <Navbar />
          <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 mb-20">{children}</main>
          <UserProfileModal />
          <DisclaimerBanner />
        </ProfileProvider>
      </body>
    </html>
  );
}
