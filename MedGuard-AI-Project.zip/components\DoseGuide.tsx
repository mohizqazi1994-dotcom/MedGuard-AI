'use client';

import React, { useState, useEffect } from 'react';
import {
  Calculator,
  Upload,
  Sparkles,
  Scale,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Syringe,
  Binary,
  Edit2,
  Lock,
  Volume2,
  Printer,
} from 'lucide-react';
import { useUserProfile } from '@/lib/profile-context';
import { extractMedLabelVisionClient } from '@/lib/ai-service';
import { calculatePediatricDose, DosageResult } from '@/lib/dosage-calculator';

export function DoseGuide() {
  const { profile, setProfileModalOpen } = useUserProfile();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [extractedDrug, setExtractedDrug] = useState<string>('');
  const [extractedConcentration, setExtractedConcentration] = useState<string>('');
  const [dosageCalculation, setDosageCalculation] = useState<DosageResult | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    if (extractedDrug || extractedConcentration) {
      const result = calculatePediatricDose(
        extractedDrug || "Children's Liquid Medicine",
        extractedConcentration || '160mg/5mL',
        profile.weightKg
      );
      setDosageCalculation(result);
    }
  }, [profile.weightKg, extractedDrug, extractedConcentration]);

  const loadTylenolSample = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, 600, 400);

      ctx.fillStyle = '#0284c7';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText("CHILDREN'S LIQUID MEDICATION LABEL", 30, 50);

      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText("CHILDREN'S TYLENOL", 30, 110);

      ctx.fillStyle = '#475569';
      ctx.font = 'bold 20px monospace';
      ctx.fillText('Active Ingredient: Acetaminophen', 30, 160);

      ctx.fillStyle = '#e11d48';
      ctx.font = 'bold 32px sans-serif';
      ctx.fillText('160 mg per 5 mL', 30, 230);

      ctx.fillStyle = '#64748b';
      ctx.font = '14px sans-serif';
      ctx.fillText('Oral Suspension - Pain & Fever Reducer', 30, 280);
    }
    const sampleUrl = canvas.toDataURL('image/jpeg');
    setImagePreview(sampleUrl);
    handleAnalyze(sampleUrl);
  };

  const loadMotrinSample = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#fff7ed';
      ctx.fillRect(0, 0, 600, 400);

      ctx.fillStyle = '#c2410c';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText("CHILDREN'S MOTRIN ORAL SUSPENSION", 30, 50);

      ctx.fillStyle = '#7c2d12';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText("CHILDREN'S MOTRIN (Ibuprofen)", 30, 110);

      ctx.fillStyle = '#d97706';
      ctx.font = 'bold 20px monospace';
      ctx.fillText('Active Ingredient: Ibuprofen', 30, 160);

      ctx.fillStyle = '#e11d48';
      ctx.font = 'bold 32px sans-serif';
      ctx.fillText('100 mg per 5 mL', 30, 230);
    }
    const sampleUrl = canvas.toDataURL('image/jpeg');
    setImagePreview(sampleUrl);
    handleAnalyze(sampleUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        handleAnalyze(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async (base64Data: string) => {
    setLoading(true);
    try {
      const visionRes = await extractMedLabelVisionClient(base64Data);
      setExtractedDrug(visionRes.drugName);
      setExtractedConcentration(visionRes.concentrationStr);

      const calcResult = calculatePediatricDose(
        visionRes.drugName,
        visionRes.concentrationStr,
        profile.weightKg
      );
      setDosageCalculation(calcResult);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Voice Reader Assistant
  const speakDosage = () => {
    if (!dosageCalculation || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const text = `Calculated single dose for ${dosageCalculation.drugName} is ${dosageCalculation.calculatedDoseMl} milliliters, containing ${dosageCalculation.calculatedDoseMg} milligrams of active medicine for a ${profile.weightKg} kilogram patient. Do not exceed ${dosageCalculation.maxDailyDoses} doses in 24 hours.`;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-md shadow-cyan-600/20">
            <Calculator className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">DoseGuide • Pediatric Dosage Engine</h2>
              <span className="flex items-center gap-1 rounded-full bg-cyan-100 px-2 py-0.5 text-[10px] font-bold text-cyan-800 border border-cyan-200">
                <Lock className="h-3 w-3" /> Deterministic Code Formula
              </span>
            </div>
            <p className="text-xs text-slate-500">
              AI Vision extracts label concentration — JS code executes strict mg/kg dose volume
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadTylenolSample}
            className="flex items-center gap-1.5 rounded-xl border border-cyan-200 bg-cyan-50 px-3 py-2 text-xs font-bold text-cyan-700 hover:bg-cyan-600 hover:text-white transition-all"
          >
            <Sparkles className="h-3.5 w-3.5" /> Test Tylenol (160mg/5mL)
          </button>
          <button
            onClick={loadMotrinSample}
            className="flex items-center gap-1.5 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700 hover:bg-amber-600 hover:text-white transition-all"
          >
            <Sparkles className="h-3.5 w-3.5" /> Test Motrin (100mg/5mL)
          </button>
        </div>
      </div>

      {/* Active Patient Bar */}
      <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 border border-cyan-200">
            <Scale className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-600">
              Active Patient: <span className="font-bold text-slate-900">{profile.name}</span>
            </div>
            <div className="text-sm font-black text-cyan-700">{profile.weightKg} kg</div>
          </div>
        </div>
        <button
          onClick={() => setProfileModalOpen(true)}
          className="flex items-center gap-1.5 text-xs font-bold text-cyan-700 hover:text-cyan-800 underline"
        >
          <Edit2 className="h-3.5 w-3.5" /> Switch / Edit Profile
        </button>
      </div>

      {/* Upload Zone */}
      {!imagePreview && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          className={`relative flex flex-col items-center justify-center rounded-3xl border-2 border-dashed p-10 text-center transition-all ${
            dragActive
              ? 'border-cyan-500 bg-cyan-50'
              : 'border-slate-300 bg-white hover:border-slate-400 shadow-sm'
          }`}
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="absolute inset-0 cursor-pointer opacity-0"
          />
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-50 text-cyan-700 border border-cyan-100 shadow-xs">
            <Upload className="h-8 w-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">
            Upload Medicine Bottle Label Photo
          </h3>
          <p className="mt-1 text-xs text-slate-500">
            Extracts drug concentration ratio (e.g. 160mg/5mL) via Vision OCR
          </p>
          <div className="mt-6 flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3.5 py-1.5 text-xs text-slate-600">
            <Lock className="h-3.5 w-3.5 text-cyan-600" /> AI vision is restricted from computing doses; code logic handles math
          </div>
        </div>
      )}

      {/* Results View */}
      {imagePreview && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-3">
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
              <img
                src={imagePreview}
                alt="Medicine Label"
                className="h-56 w-full object-cover rounded-xl border border-slate-200"
              />
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">Bottle Label Source</span>
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setDosageCalculation(null);
                  }}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-900"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Replace Image
                </button>
              </div>
            </div>

            {loading && (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-cyan-200 bg-cyan-50 p-6 text-center">
                <RefreshCw className="h-8 w-8 animate-spin text-cyan-600" />
                <p className="mt-3 text-xs font-bold text-cyan-800">
                  Parsing Drug Label & Running Deterministic Math Engine...
                </p>
              </div>
            )}
          </div>

          <div className="md:col-span-2 space-y-5">
            {dosageCalculation && (
              <>
                {/* MASSIVE LIGHT MODE DOSAGE CARD */}
                <div className="overflow-hidden rounded-3xl border-2 border-cyan-600 bg-gradient-to-br from-cyan-600 to-blue-700 p-7 text-white shadow-xl shadow-cyan-600/20">
                  <div className="flex items-center justify-between border-b border-white/20 pb-3">
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-100">
                      <Syringe className="h-4 w-4" /> Calculated Single Dose Volume
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={speakDosage}
                        className={`flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold transition-all ${
                          isSpeaking ? 'bg-amber-400 text-slate-950 animate-pulse' : 'bg-white/20 text-white hover:bg-white/30'
                        }`}
                      >
                        <Volume2 className="h-3.5 w-3.5" /> {isSpeaking ? 'Speaking...' : 'Read Aloud'}
                      </button>
                      <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-bold text-white border border-white/30">
                        {profile.weightKg} kg Patient
                      </span>
                    </div>
                  </div>

                  <div className="my-6 text-center sm:text-left">
                    <div className="text-xs font-bold text-cyan-100 uppercase tracking-widest">
                      RECOMMENDED LIQUID DOSE
                    </div>
                    <div className="mt-2 flex flex-col sm:flex-row sm:items-baseline gap-2">
                      <span className="text-6xl sm:text-7xl font-black tracking-tight text-white drop-shadow-md">
                        {dosageCalculation.calculatedDoseMl}
                      </span>
                      <span className="text-3xl font-black text-cyan-200">mL</span>
                      <span className="text-sm font-semibold text-cyan-100 sm:ml-4">
                        ({dosageCalculation.calculatedDoseMg} mg active ingredient)
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 rounded-2xl bg-white/10 p-4 backdrop-blur-md text-xs border border-white/20">
                    <div>
                      <span className="text-cyan-100">Extracted Drug:</span>
                      <div className="font-bold text-white">{dosageCalculation.drugName}</div>
                    </div>
                    <div>
                      <span className="text-cyan-100">Extracted Concentration:</span>
                      <div className="font-bold text-cyan-200">
                        {dosageCalculation.concentrationRatioStr}
                      </div>
                    </div>
                  </div>
                </div>

                {/* INTERACTIVE ORAL SYRINGE VISUALIZER */}
                <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm font-bold text-cyan-700">
                      <Syringe className="h-4 w-4" /> Syringe Fill Visualizer (10 mL Oral Syringe)
                    </div>
                    <span className="text-xs font-extrabold text-cyan-700">Fill Level: {dosageCalculation.calculatedDoseMl} mL</span>
                  </div>

                  {/* Graphic Syringe SVG */}
                  <div className="mt-4 relative h-20 w-full overflow-hidden rounded-xl border border-slate-300 bg-slate-100 p-2">
                    {/* Syringe barrel container */}
                    <div className="relative h-full w-full rounded-lg bg-white border-2 border-slate-400 overflow-hidden flex items-center">
                      {/* Fluid fill line */}
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 transition-all duration-700 flex items-center justify-end pr-2 font-bold text-xs text-white"
                        style={{ width: `${Math.min(100, (dosageCalculation.calculatedDoseMl / 10) * 100)}%` }}
                      >
                        {dosageCalculation.calculatedDoseMl} mL
                      </div>
                      {/* Milliliter Tick Mark Grid */}
                      <div className="absolute inset-0 flex justify-between px-2 text-[9px] font-mono text-slate-500 pointer-events-none items-end pb-1">
                        <span>0</span>
                        <span>2mL</span>
                        <span>4mL</span>
                        <span>6mL</span>
                        <span>8mL</span>
                        <span>10mL</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Math Breakdown */}
                <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-center gap-2 text-sm font-bold text-cyan-700">
                    <Binary className="h-4 w-4" /> Deterministic Formula Verification Steps
                  </div>
                  <div className="mt-3 space-y-2 font-mono text-xs text-slate-800">
                    {dosageCalculation.mathSteps.map((step, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl bg-slate-50 p-2.5 border border-slate-200 text-slate-900"
                      >
                        {step}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Safety Rules */}
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 shadow-sm">
                  <div className="flex items-center gap-2 text-sm font-bold text-amber-800">
                    <AlertTriangle className="h-4 w-4 text-amber-600" /> Pediatric Administration Safety Rules
                  </div>
                  <ul className="mt-3 space-y-2 text-xs text-slate-700">
                    {dosageCalculation.safetyWarnings.map((warn, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
                        <span>{warn}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
