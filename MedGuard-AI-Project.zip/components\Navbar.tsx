'use client';

import React from 'react';
import { Shield, User, Pill, Activity } from 'lucide-react';
import { useUserProfile } from '@/lib/profile-context';

export function Navbar() {
  const { profile, setProfileModalOpen } = useUserProfile();

  const medCount = profile.activeMedications
    ? profile.activeMedications.split(',').filter((m) => m.trim().length > 0).length
    : 0;

  const conditionCount = profile.conditionsAllergies
    ? profile.conditionsAllergies.split(',').filter((c) => c.trim().length > 0).length
    : 0;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/90 backdrop-blur-md shadow-xs">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                MedGuard<span className="bg-gradient-to-r from-cyan-600 to-indigo-600 bg-clip-text text-transparent"> AI</span>
              </h1>
              <span className="rounded-full bg-cyan-100 px-2 py-0.5 text-[10px] font-bold tracking-wider text-cyan-800 border border-cyan-200">
                PRO V1.0
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Multimodal Vision & Deterministic Clinical Logic
            </p>
          </div>
        </div>

        {/* User Profile Pill Trigger */}
        <button
          onClick={() => setProfileModalOpen(true)}
          className="group flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-1.5 text-left transition-all hover:border-cyan-500 hover:bg-cyan-50/50 hover:shadow-md"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-600 text-white shadow-xs">
            <User className="h-4 w-4" />
          </div>
          <div className="text-xs">
            <div className="flex items-center gap-2 font-semibold text-slate-900">
              <span>Patient Profile</span>
              <span className="text-slate-300">•</span>
              <span className="text-cyan-700 font-bold">{profile.weightKg} kg</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <Pill className="h-3 w-3 text-indigo-600" /> {medCount} Meds
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Activity className="h-3 w-3 text-amber-600" /> {conditionCount} Conditions
              </span>
            </div>
          </div>
        </button>
      </div>
    </header>
  );
}
